module.exports = {
  plugins: {
  },
}
