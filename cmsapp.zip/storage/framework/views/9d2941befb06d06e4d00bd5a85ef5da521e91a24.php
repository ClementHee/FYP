

<title> Edit Event </title>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Edit Event</h2>
        </div>
    </div>

    <div class="pull-right my-4">
        <a class="btn btn-primary" href="<?php echo e(route('event.index')); ?>"> Back</a>
    </div>
</div>


<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

    <form
        action="<?php echo e(route('event.update', $edit_event->eventId)); ?>"
        method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <div class="input-group mb-3">
            <span class="input-group-text">Name:</span>
        <input
            type="text"
            name="name"
            value="<?php echo e($edit_event->name); ?>"
            class="form-control">
        </div>

        <div class="input-group mb-3">
            <label class="input-group-text" for="date_time">From: </label>
            <input type="datetime-local" name="start_datetime"  class="form-control" value="<?php echo e($edit_event->start_datetime); ?>">
        </div>

        <div class="input-group mb-3">
            <label class="input-group-text" for="date_time">To: </label>
            <input type="datetime-local" name="end_datetime" class="form-control" value="<?php echo e($edit_event->end_datetime); ?>">
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Venue:</span>
        <input
            type="text"
            name="venue"
            value="<?php echo e($edit_event->venue); ?>"
            class="form-control">
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Person In Charge:</span>
        <input
            type="text"
            name="pic"
            value="<?php echo e($edit_event->pic); ?>"
            class="form-control">
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text">Event Type:</span>
            <select name = "eventtype" class="form-control">
                <?php $__currentLoopData = $eventtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value = "<?php echo e($selection->name); ?>"><?php echo e($selection->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary my-4">Save</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/event/editevent.blade.php ENDPATH**/ ?>