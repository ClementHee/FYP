

<title> Edit Not Available Time </title>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Edit Not Available Time</h2>
        </div>
    </div>

    <div class="pull-right my-4">
        <a class="btn btn-primary" href="<?php echo e(route('profile.index')); ?>"> Back</a>
    </div>
</div>


<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

    <form
        action="<?php echo e(route('not_availabletime.updatethis',['profile'=>$edit_natime->profileId,'time'=>$edit_natime->na_time])); ?>"
        method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <strong>
            <label class = "form-group" for="date_time">Not available time </label>
            <input type="date" name="na_time"  class="form-control" value="<?php echo e($edit_natime->na_time); ?>">
        </strong>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary my-4">Save</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/notavailtime/editnatime.blade.php ENDPATH**/ ?>