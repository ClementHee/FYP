
<title> Profile Management</title>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Profile Management</h2>
        </div>
        <div class="pull-right my-4">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create Profile')): ?>
            <a class="btn btn-success" href="<?php echo e(route('profile.create')); ?>"> Create New Profile</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="table-responsive table-sm">
<table class="table table-striped">
    <tr>
        <th>No.</th>
        <th>Name</th>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Profile')): ?>
        <th width="280px">Action</th>
        <?php endif; ?>
    </tr>

    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($profile->name); ?></td>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Profile')): ?>
        <td>
            <a class="btn btn-primary my-1" href="<?php echo e(route('profile.show',$profile->profileId)); ?>">Show</a>

                <a class="btn btn-two my-1" href="<?php echo e(route('profile.edit',$profile->profileId)); ?>">Edit</a>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Profile')): ?>
                <?php echo Form::open(['method' => 'DELETE','route' => ['profile.destroy', $profile->profileId],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger my-1']); ?>

                <?php echo Form::close(); ?>

            <?php endif; ?>
        </td>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php echo $profiles->render('pagination::bootstrap-5'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/profile/profiles.blade.php ENDPATH**/ ?>