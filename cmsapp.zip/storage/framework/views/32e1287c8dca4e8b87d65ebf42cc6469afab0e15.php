

<title> <?php echo e($event->name); ?> </title>

<?php $__env->startSection('content'); ?>
<body>

    <div class="pull-right my-4">
        <a class="btn btn-primary" href="<?php echo e(route('event.index')); ?>"> Back</a>
    </div>

    <div class="card">
        <div class="card-header">
            <h2>Event Data</h2>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <div class="form-group">
                        <strong>Name:</strong>
                        <?php echo e($event->name); ?>

                    </div>

                    <div class="form-group">
                        <strong>Type:</strong>
                        <?php echo e($event->eventtype); ?>

                    </div>

                    <div class="form-group">
                        <strong>Start Time:</strong>
                        <?php echo e($event->start_datetime); ?>

                    </div>

                    <div class="form-group">
                        <strong>End Time:</strong>
                        <?php echo e($event->end_datetime); ?>

                    </div>

                    <div class="form-group">
                        <strong>Venue:</strong>
                        <?php echo e($event->venue); ?>

                    </div>

                    <div class="form-group">
                        <strong>Person In Charge:</strong>
                        <?php echo e($event->pic); ?>

                    </div>

                    <div class="button-group">
                        <a  class="btn btn-primary my-2" href= "<?php echo e(route('event.edit',$event->eventId)); ?> ">
                            Edit Event
                        </a>

                        <a class="btn btn-two my-2" href="<?php echo e(route('generateschedule',$event->eventId)); ?>">Generate Schedule</a>
                        <a class="btn btn-two my-2" href="<?php echo e(route('schedule.show',$event->eventId)); ?>">Show Schedule</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Event')): ?>
                            <?php echo Form::open(['method' => 'DELETE','route' => ['schedule.destroy', $event->eventId],'style'=>'display:inline']); ?>

                                <?php echo Form::submit('Delete Schedule', ['class' => 'btn btn-danger my-2']); ?>

                            <?php echo Form::close(); ?>


                                <?php echo Form::open(['method' => 'DELETE','route' => ['event.destroy', $event->eventId],'style'=>'display:inline']); ?>

                                    <?php echo Form::submit('Delete Event', ['class' => 'btn btn-danger my-2']); ?>

                                <?php echo Form::close(); ?><?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </div>

</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/event/showevent.blade.php ENDPATH**/ ?>