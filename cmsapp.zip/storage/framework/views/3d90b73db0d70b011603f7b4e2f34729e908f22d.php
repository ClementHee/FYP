

<title> Volunteer Roles </title>

<?php $__env->startSection('content'); ?>
<body class="w-full h-full bg-gray-100">
    <div class="container">
        <div class="row justify-content-center">
            <h2>
                Volunteer Roles
            </h2>
        </div>

        <div class="pull-right my-4">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create Volunteer Type')): ?>
            <a class="btn btn-success"
            href="<?php echo e(route('roles.create')); ?>">
             Create  Volunteer Roles
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php if(session()->has('message')): ?>
        <div class="container">
            <div class = "invalid-feedback">
                Warning
            </div>
            <div class="invalid-feedback">
                <?php echo e(session()->get('message')); ?>

            </div>
        </div>
    <?php endif; ?>
<div class="table table-responsive">
    <table class="table table-striped table-sm">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th width="280px">Action</th>
        </tr>

        <?php $__currentLoopData = $vroles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vrole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($vrole->name); ?></td>
            <td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Show Volunteer Type')): ?>
                <a class="btn btn-primary my-1" href="<?php echo e(route('roles.show',$vrole->roleId)); ?>">Show</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Volunteer Type')): ?>
                <a class="btn btn-two my-1" href="<?php echo e(route('roles.edit',$vrole->roleId)); ?>">Edit</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Volunteer Type')): ?>
                <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $vrole->roleId],'style'=>'display:inline']); ?>

                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger my-1']); ?>

                <?php echo Form::close(); ?>

                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
    <?php echo $vroles->render('pagination::bootstrap-5'); ?>


</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/roles/roles.blade.php ENDPATH**/ ?>