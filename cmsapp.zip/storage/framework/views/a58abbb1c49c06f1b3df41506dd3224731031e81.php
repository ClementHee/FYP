
<title>Show System Role</title>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2> Show System Role</h2>
        </div>
        <div class="pull-right my-4">
            <a class="btn btn-primary" href="<?php echo e(route('usertype.index')); ?>"> Back</a>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="list-group">
            <h3><?php echo e($role->name); ?></h3>
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <ol class="list-group list-group-numbered ">
            <strong>Permissions:</strong>
                <?php if(!empty($rolePermissions)): ?>
                    <?php $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <label class="label label-success">
                            <?php echo e($v->name); ?>

                        </label>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
        </ol>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/usertype/showroles.blade.php ENDPATH**/ ?>