

<title> Create Event </title>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Create New Event</h2>
        </div>
    </div>

    <div class="pull-right my-4">
        <a class="btn btn-primary" href="<?php echo e(route('event.index')); ?>"> Back</a>
    </div>
</div>


<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

    <form
        action="<?php echo e(route('event.store')); ?>"
        method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <p> Name:
        <input
            type="text"
            name="name"
            placeholder="Name"
            class="col-xs-12 col-sm-12 col-md-12">
        </p>

        

        <p>
            <label for="date_time">From </label>
            <input type="datetime-local" name="start_datetime"  class="bg-transparent block border-b-2 w-full h-20 text-2xl outline-none">
        </p>

        <p>
            <label for="date_time">To: </label>
            <input type="datetime-local" name="end_datetime"  class="bg-transparent block border-b-2 w-full h-20 text-2xl outline-none">
        </p>

        <p> Venue:
        <input
            type="text"
            name="venue"
            placeholder="Venue"
            class="col-xs-12 col-sm-12 col-md-12">
        </p>

        <p> Person In Charge:
        <input
            type="text"
            name="pic"
            placeholder="Person In Charge"
            class="col-xs-12 col-sm-12 col-md-12">
        </p>
        <p> Event Type
            <select name = "eventtype" class="col-xs-12 col-sm-12 col-md-12">
                <?php $__currentLoopData = $eventtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value = "<?php echo e($selection->name); ?>"><?php echo e($selection->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
            </select>
            </p>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/event/createvent.blade.php ENDPATH**/ ?>