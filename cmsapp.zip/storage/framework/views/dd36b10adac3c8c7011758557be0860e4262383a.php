
<title> Show Event Sets </title>
<?php $__env->startSection('content'); ?>

    <h2> Show Event Sets</h2>
    <div class="pull-right my-4">
        <a class="btn btn-primary" href="<?php echo e(route('eventtypes.index')); ?>"> Back</a>
        <a class="btn btn-primary" href="<?php echo e(route('eventroles.edit',$eventtypes->eventtypeId)); ?>"> Assign Roles for event</a>
    </div>

<div class="card">
    <div class="card-header">
        <h2><?php echo e($eventtypes->name); ?></h2>
    </div>
    <div class="card-body">
        <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <ul class="list-group">
                <strong>Events in this category: </strong>
                <?php $__currentLoopData = $assignedevents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedevent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <?php echo e($assignedevent->name); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
            </ul>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

            <ul class="list-group">
            <strong>Roles needed: </strong>
            <?php $__currentLoopData = $rolesneeded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleneeded): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
                <?php echo e($roleneeded->name); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        </div>
            <div class="pull-right my-4">
            <a class="btn btn-primary" href="<?php echo e(route('eventroles.edit',$eventtypes->eventtypeId)); ?>"> Edit Roles for Events</a>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/eventtype/showtypes.blade.php ENDPATH**/ ?>