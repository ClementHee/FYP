

<title> Event Set Types </title>

<?php $__env->startSection('content'); ?>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <h1 class="text-3xl text-gray-700">
                Event Set Type
            </h1>
        </div>

        <div class="pull-right my-4">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create Event Type')): ?>
            <a class="btn btn-success"
               href="<?php echo e(route('eventtypes.create')); ?>">
                Create Event Set Type
            </a><?php endif; ?>
        </div>
    </div>
    <?php if(session()->has('message')): ?>
        <div class="container">
            <div class = "invalid-feedback">
                Warning
            </div>
            <div class="invalid-feedback">
                <?php echo e(session()->get('message')); ?>

            </div>
        </div>
    <?php endif; ?>
<div class="table-responsive">
    <table class="table table-striped table-sm">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th width="280px">Action</th>
        </tr>

        <?php $__currentLoopData = $eventtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($eventtype->name); ?></td>
            <td>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Show Event Type')): ?>
                    <a class="btn btn-primary my-2" href="<?php echo e(route('eventtypes.show',$eventtype->eventtypeId)); ?>">Show</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Event Type')): ?>
                    <a class="btn btn-two my-2" href="<?php echo e(route('eventtypes.edit',$eventtype->eventtypeId)); ?>">Edit</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Event Type')): ?>
                    <?php echo Form::open(['method' => 'DELETE','route' => ['eventtypes.destroy', $eventtype->eventtypeId],'style'=>'display:inline']); ?>

                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger my-2']); ?>

                    <?php echo Form::close(); ?>

                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
    <?php echo $eventtypes->render('pagination::bootstrap-5'); ?>


</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/eventtype/eventtypes.blade.php ENDPATH**/ ?>