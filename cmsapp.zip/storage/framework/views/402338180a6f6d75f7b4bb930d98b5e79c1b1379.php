

<title> Edit Volunteer Type </title>

<?php $__env->startSection('content'); ?>
<body>
<div class="col-xs-12 col-sm-12 col-md-12">
    <div class="row justify-content-center">
        <h1>
            Edit Volunteer Type
        </h1>
    </div>

    <div class="row justify-content-center">
        <?php if($errors->any()): ?>
            <div class='invalid-feedback'>
                Something went wrong
            </div>
            <ul class='invalid-feedback'>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="py-2">
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>

    <div class="container border border-0">
        <?php echo Form::model($volunteer_type, ['method' => 'PATCH','route' => ['vtypes.update', $profileId]]); ?>

        <div class="d-none">
            <strong>Profile ID:</strong>
            <input
            type="text" name="profileId" value= <?php echo e($profileId); ?> class="">
        </div>

        <div class="">
            <ul class="list-group ">
                <strong>Roles:</strong> <br/>
                    <?php $__currentLoopData = $alltypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <label class="form-check-label stretched-link">
                                <?php echo e(Form::checkbox('types[]', $value->roleId, in_array($value->roleId, $volunteer_type) ? true : false, array('class' => 'name'))); ?>

                                <?php echo e($value->name); ?>

                            </label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary my-4">Save</button>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/volunteertype/edittype.blade.php ENDPATH**/ ?>