

<title> Create Volunteer Type </title>

<?php $__env->startSection('content'); ?>
<body>
<div class="container">
    <div class="row justify-content-center">
        <h1 class="text-3xl text-gray-700">
            Create Volunteer Type
        </h1>
        <hr class="border border-1 border-gray-300 mt-10">
    </div>

<div class="container">
    <div class="row justify-content-center">
        <?php if($errors->any()): ?>
            <div class='invalid-feedback'>
                Something went wrong
            </div>
            <ul class='invalid-feedback'>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="py-2">
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>

    <div class="card">
        <?php echo Form::open(array('route' => 'eventroles.store','method'=>'POST')); ?>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="d-none">
                    
                    <input
                        type="text"
                        name="eventtypeId"
                        value= "<?php echo e($eventtypeId); ?>"
                        class="bg-transparent block border-b-2 w-full h-20 text-2xl outline-none">


                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Roles:</strong>
                    <br/>
                    <?php $__currentLoopData = $vroles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div clas="form-check">
                            <label class="form-check-label" for="<?php echo e($value->name); ?>">
                            <input type="checkbox" class="form-check-input" id="" name="types[]" value="<?php echo e($value->roleId); ?>">
                            <?php echo e($value->name); ?>

                            </label>
                        </div>
                    <br/>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/eventtype/assigntype.blade.php ENDPATH**/ ?>