
<title>Users Managment</title>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Users Management</h2>
        </div>
        <div class="pull-right my-4">
            <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> Create New User</a>
        </div>
    </div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<div class="table-responsive">
<table class="table table-striped table-sm">
    <tr>
        <th>No.</th>
        <th>Email</th>
        <th> System Roles</th>
        <th width="280px">Action</th>
    </tr>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>

        <td><?php echo e($user->email); ?></td>

        <td>
            <?php if(!empty($user->getRoleNames())): ?>
           
                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge rounded-pill bg-dark"><?php echo e($v); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </td>
        <td>
            <a class="btn btn-primary my-1" href="<?php echo e(route('users.show',$user->accountId)); ?>">Show</a>
            <a class="btn btn-two my-1" href="<?php echo e(route('users.edit',$user->accountId)); ?>">Edit</a>
                <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->accountId],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger my-1']); ?>

                <?php echo Form::close(); ?>

        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php echo $data->render('pagination::bootstrap-5'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/users/users.blade.php ENDPATH**/ ?>