

<title> <?php echo e($profile->name); ?> </title>

<?php $__env->startSection('content'); ?>
<body>
    <div class="card">
        <div class="card-header">
          <h2>Profile Data</h2>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <div class="form-group">
                        <strong>Name:</strong>
                        <?php echo e($profile->name); ?>

                    </div>

                    <div class="form-group">
                        <strong>Email:</strong>
                        <?php echo e($profile->email); ?>

                    </div>

                    <div class="list-group list-group-numbered">
                    <strong>Volunteer Types:</strong>
                        <?php if(!empty($allocatedtypes)): ?>
                            <?php $__currentLoopData = $allocatedtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item"> <label class="label label-success"><?php echo e($v->name); ?></label> </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                    <div class="list-group">
                        <strong>Not Available Dates:</strong>
                            <?php if(!empty($not_availtime)): ?>
                                <?php $__currentLoopData = $not_availtime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item"> <label class="label label-success"><?php echo e($nat->na_time); ?></label>
                                    <a class= "btn btn-primary my-2 float-end" href= "<?php echo e(route('not_availabletime.editthis',['profile'=>$profile->profileId,'time'=>$nat->na_time])); ?> ">
                                        Edit
                                    </a>
                                    <form action=" <?php echo e(route ('not_availabletime.delete',['profile'=>$profile->profileId,'time'=>$nat->na_time])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button  class= "btn btn-danger my-2" >
                                            Delete Time
                                        </button>
                                    </form>
                                </li>
                                
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>
                    </div>

               </div>
            </div>

            <div class="button-group">
                <a class= "btn btn-primary my-2" href= "<?php echo e(route('profile.edit',$profile->profileId)); ?> ">
                    Edit Profile
                </a>
                <a  class= "btn btn-primary my-2" href= "<?php echo e(route('vtypes.edit',$profile->profileId)); ?> ">
                    Edit Roles
                </a>
                <a  class= "btn btn-primary my-2" href= "<?php echo e(route('create_na',$profile->profileId)); ?> ">
                    Set Not Available Time
                </a>

                <form action=" <?php echo e(route ('profile.destroy',$profile->profileId)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button  class= "btn btn-danger my-2" >
                        Delete Profile
                    </button>
                </form>
            </div>
            <!-- Button trigger modal -->

        </div>
      </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/profile/showprofile.blade.php ENDPATH**/ ?>