

    <title>Edit Profile</title>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Edit Profile</h2>
        </div>
    </div>

    <div class="pull-right my-4">
        <a class="btn btn-primary" href="<?php echo e(route('profile.index')); ?>"> Back</a>
    </div>
</div>


<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

    <form
        action="<?php echo e(route('profile.update', $edit_profile->profileId)); ?>"
        method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <p> Designation:
        <input
        type="text"
        name="designation"
        class="col-xs-12 col-sm-12 col-md-12"
        value="<?php echo e($edit_profile->designation); ?>"
        >
        </p>

        <p> Name:
        <input
            type="text"
            name="name"
            class="col-xs-12 col-sm-12 col-md-12"
            value="<?php echo e($edit_profile->name); ?>"
        >
        </p>

        <p> Home Number:
        <input
            type="text"
            name="phone"
            class="col-xs-12 col-sm-12 col-md-12"
            value="<?php echo e($edit_profile->phone); ?>"
        >
        </p>

        <p>Phone Numebr:
        <input
            type="text"
            name="handphoneNo"
            class="col-xs-12 col-sm-12 col-md-12"
            value="<?php echo e($edit_profile->handphoneNo); ?>"
        >
        </p>

        <p>Email
        <input
            type="email"
            name="email"
            class="col-xs-12 col-sm-12 col-md-12"
            value="<?php echo e($edit_profile->email); ?>"
        >
        </p>

        <p>Address:
        <textarea
            name="address"
            placeholder="Address"
            class="col-xs-12 col-sm-12 col-md-12"
            ><?php echo e($edit_profile->address); ?></textarea>
        </p>

        <p>Gender
            <select name = "gender" class="col-xs-12 col-sm-12 col-md-12">
                <option value = "Male" <?php echo e($edit_profile->gender == "Male" ? 'selected':''); ?>>Male</option>
                <option value = "Female">Female</option>
            </select>
        </p>

        <p>Congregation
        <select name = "congregation" class="col-xs-12 col-sm-12 col-md-12">
            <?php $__currentLoopData = $congregations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value = "<?php echo e($selection->name); ?>" <?php echo e($edit_profile->congregation == $selection->name ? 'selected':''); ?>>
                    <?php echo e($selection->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </p>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/profile/editprofile.blade.php ENDPATH**/ ?>