

<title> Create Profile </title>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Create New Profile</h2>
            </div>
        </div>

        <div class="pull-right my-4">
            <a class="btn btn-primary" href="<?php echo e(route('profile.index')); ?>"> Back</a>
        </div>
    </div>


<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

    <form
        action="<?php echo e(route('profile.store')); ?>"
        method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="input-group mb-3">
            <span class="input-group-text">Designation:</span>
        <input
            class="form-control"
            type="text"
            name="designation"
            placeholder="Mr">
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Name:</span>
        <input
            class="form-control"
            type="text"
            name="name"
            placeholder="Name">
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Home Number:</span>
        <input
            type="text"
            name="phone"
            placeholder="Phone"
            class="form-control">
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Phone Number:</span>
        <input
            type="text"
            name="handphoneNo"
            placeholder="Mobile Phone"
            class="form-control">
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Email</span>
        <input
            type="email"
            name="email"
            class="form-control"
            <?php if(isset($email)): ?>
                value="<?php echo e($email); ?>" readonly
            <?php else: ?>
                placeholder="Email"
            <?php endif; ?>>
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text"> Address: </span>
        <textarea
            name="address"
            rows="3"
            placeholder="Address"
            class="form-control">
        </textarea>
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Gender</span>
            <select name = "gender" class="form-control">

                <option value = "Male">Male</option>
                <option value = "Female">Female</option>

            </select>
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Congregation</span>
        <select name = "congregation" class="form-control">
            <?php $__currentLoopData = $congregations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value = "<?php echo e($selection->name); ?>"><?php echo e($selection->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
    </div>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-app\resources\views/profile/createprofile.blade.php ENDPATH**/ ?>